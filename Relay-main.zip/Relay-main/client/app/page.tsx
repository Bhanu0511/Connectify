import Router from "@/utils/router";

export default function HomePage() {
  return <Router />;
}
